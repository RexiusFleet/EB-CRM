# Deploying the Edge Functions without the dashboard editor

The Supabase dashboard's in-browser editor was reporting "function updated" and
then showing an empty editor. That means the code being run was never the code
pasted in — which accounts for every symptom we chased: no response at all, then
a response with no CORS headers.

This folder deploys the functions from files instead. Unzip it into the **root of
your GitHub repo** (the same place `index.html` lives), keeping the folder
structure:

    .github/workflows/deploy-supabase-functions.yml
    supabase/config.toml
    supabase/functions/calendar/index.ts
    supabase/functions/hello/index.ts

## One-time setup — all in a browser, no terminal

1. **Make a Supabase access token.**
   <https://supabase.com/dashboard/account/tokens> → Generate new token →
   name it `github actions` → copy it. It is shown only once.

2. **Give it to GitHub.**
   Your repo → **Settings** → **Secrets and variables** → **Actions** →
   **New repository secret**.
   Name: `SUPABASE_ACCESS_TOKEN`   Value: the token you just copied.

3. **Commit these files** (drag them into the GitHub web UI if that's easiest).

4. **Run it.** Repo → **Actions** tab → **Deploy Supabase functions** →
   **Run workflow**.

It takes about a minute. Green tick = deployed. Open the run's log to see the
line-count check and the last three lines of `calendar/index.ts`, which is how
you know nothing was truncated this time.

From then on, any change under `supabase/functions/` deploys itself on push.

## What this fixes at the same time

The workflow deploys with `--no-verify-jwt`. That switches off Supabase's
*gateway* authentication check — which is also what rejects the browser's CORS
preflight, since an `OPTIONS` request carries no Authorization header. That was
the other live suspect, and this removes it.

It does **not** make the function public. `calendar/index.ts` calls
`requireUser()` as the first thing on every request: it takes the caller's token,
verifies it against `/auth/v1/user`, and refuses anyone without a valid session
before touching Google. The anon key alone gets nowhere — it is not a user token.

## Two notes

- Your repo is served by GitHub Pages, so `supabase/functions/*.ts` will be
  publicly readable. That is fine — those files contain no credentials. The
  service-account key lives only in the Supabase secret and appears nowhere in
  the repo. Do not put it here.
- The `GOOGLE_SERVICE_ACCOUNT` secret you already created in Supabase is
  untouched by this. Deploying a function does not clear its secrets.

## Then

Run `fndiag.html` again. If it comes back clean, open the app's **Rate Card** tab
and press **Check** on the Calendar connection card.
